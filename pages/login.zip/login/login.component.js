"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var LoginComponent = /** @class */ (function () {
    function LoginComponent(router) {
        this.router = router;
    }
    LoginComponent.prototype.onTapSignIn = function () {
        if (this.emailAddress != null && this.password != null) {
            alert("Welcome Back");
            var navigationExtras = {
                queryParams: {
                    "firstName": "Nic",
                    "lastName": "Logan"
                }
            };
            this.router.navigate(["Home"], navigationExtras);
        }
    };
    LoginComponent.prototype.onTapUser = function () {
        this.router.navigate(["Home"]);
    };
    LoginComponent.prototype.onTapBack = function () {
        this.router.navigate(["TempNavigation"]);
    };
    LoginComponent.prototype.onTapRegister = function () {
        this.router.navigate(["Register"]);
    };
    LoginComponent = __decorate([
        core_1.Component({
            selector: "LoginComponent",
            moduleId: module.id,
            templateUrl: "./login.html",
            styleUrls: ['./login-common.css']
        }),
        __metadata("design:paramtypes", [router_1.Router])
    ], LoginComponent);
    return LoginComponent;
}());
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9naW4uY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibG9naW4uY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQTBDO0FBQzFDLDBDQUF3RDtBQWF4RDtJQUdJLHdCQUEyQixNQUFjO1FBQWQsV0FBTSxHQUFOLE1BQU0sQ0FBUTtJQUV6QyxDQUFDO0lBRU0sb0NBQVcsR0FBbEI7UUFFSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsUUFBUSxJQUFHLElBQUksQ0FBQyxDQUN0RCxDQUFDO1lBQ0MsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ3RCLElBQUksZ0JBQWdCLEdBQXFCO2dCQUN2QyxXQUFXLEVBQUU7b0JBQ2IsV0FBVyxFQUFFLEtBQUs7b0JBQ2xCLFVBQVUsRUFBRSxPQUFPO2lCQUNwQjthQUNGLENBQUE7WUFDQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLGdCQUFnQixDQUFDLENBQUM7UUFDbkQsQ0FBQztJQUVMLENBQUM7SUFFTSxrQ0FBUyxHQUFoQjtRQUVFLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBQ00sa0NBQVMsR0FBaEI7UUFFRSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBRU0sc0NBQWEsR0FBcEI7UUFFRSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQW5DUSxjQUFjO1FBUjFCLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsZ0JBQWdCO1lBQzFCLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixXQUFXLEVBQUMsY0FBYztZQUMxQixTQUFTLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQztTQUNsQyxDQUFDO3lDQU1xQyxlQUFNO09BSGhDLGNBQWMsQ0FvQzFCO0lBQUQscUJBQUM7Q0FBQSxBQXBDRCxJQW9DQztBQXBDWSx3Q0FBYyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7Um91dGVyLCBOYXZpZ2F0aW9uRXh0cmFzfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCJcclxuXHJcblxyXG5pbXBvcnQgeyBGb3JtU3R5bGUgfSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogXCJMb2dpbkNvbXBvbmVudFwiLFxyXG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXHJcbiAgdGVtcGxhdGVVcmw6XCIuL2xvZ2luLmh0bWxcIiwgXHJcbiAgc3R5bGVVcmxzOiBbJy4vbG9naW4tY29tbW9uLmNzcyddXHJcbn0pXHJcblxyXG5cclxuZXhwb3J0IGNsYXNzIExvZ2luQ29tcG9uZW50IHtcclxuICBlbWFpbEFkZHJlc3MgO1xyXG4gIHBhc3N3b3JkIDsgXHJcbiAgICBwdWJsaWMgY29uc3RydWN0b3IocHJpdmF0ZSByb3V0ZXI6IFJvdXRlcil7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvblRhcFNpZ25Jbigpe1xyXG5cclxuICAgICAgICBpZiAodGhpcy5lbWFpbEFkZHJlc3MgIT0gbnVsbCAmJiB0aGlzLnBhc3N3b3JkICE9bnVsbClcclxuICAgICAgICB7XHJcbiAgICAgICAgICBhbGVydChgV2VsY29tZSBCYWNrYCk7XHJcbiAgICAgICAgICBsZXQgbmF2aWdhdGlvbkV4dHJhczogTmF2aWdhdGlvbkV4dHJhcyA9IHtcclxuICAgICAgICAgICAgcXVlcnlQYXJhbXM6IHtcclxuICAgICAgICAgICAgXCJmaXJzdE5hbWVcIjogXCJOaWNcIixcclxuICAgICAgICAgICAgXCJsYXN0TmFtZVwiOiBcIkxvZ2FuXCJcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbXCJIb21lXCJdLCBuYXZpZ2F0aW9uRXh0cmFzKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uVGFwVXNlcigpXHJcbiAgICB7XHJcbiAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFtcIkhvbWVcIl0pO1xyXG4gICAgfVxyXG4gICAgcHVibGljIG9uVGFwQmFjaygpXHJcbiAgICB7XHJcbiAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFtcIlRlbXBOYXZpZ2F0aW9uXCJdKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25UYXBSZWdpc3RlcigpXHJcbiAgICB7XHJcbiAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFtcIlJlZ2lzdGVyXCJdKTtcclxuICAgIH1cclxufVxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuIl19